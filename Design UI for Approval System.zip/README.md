
  # Design UI for Approval System

  This is a code bundle for Design UI for Approval System. The original project is available at https://www.figma.com/design/heKHZgBRDpoSYM6CO76Kdv/Design-UI-for-Approval-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  