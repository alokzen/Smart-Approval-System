import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { Dashboard } from "./components/Dashboard";
import { MyApprovalRequests } from "./components/MyApprovalRequests";
import { CreateRequest } from "./components/CreateRequest";
import { MyApprovals } from "./components/MyApprovals";
import { ApprovalAction } from "./components/ApprovalAction";
import { DOPPolicy } from "./components/DOPPolicy";
import { ApprovalList } from "./components/ApprovalList";
import { LeadTimes } from "./components/LeadTimes";

export default function App() {
  const [activeScreen, setActiveScreen] = useState("dashboard");
  const [selectedRequestId, setSelectedRequestId] = useState<string | undefined>();
  const [userRole] = useState<"admin" | "approver" | "requester" | "viewer">("admin");

  const handleNavigate = (screen: string, requestId?: string) => {
    setActiveScreen(screen);
    if (requestId) {
      setSelectedRequestId(requestId);
    }
  };

  const renderContent = () => {
    switch (activeScreen) {
      case "dashboard":
        return <Dashboard onNavigate={handleNavigate} />;
      case "my-requests":
        return <MyApprovalRequests onNavigate={handleNavigate} />;
      case "create-request":
        return <CreateRequest onNavigate={handleNavigate} requestId={selectedRequestId} />;
      case "my-approvals":
        return <MyApprovals onNavigate={handleNavigate} />;
      case "approval-action":
        return <ApprovalAction onNavigate={handleNavigate} requestId={selectedRequestId} />;
      case "dop-policy":
        return <DOPPolicy />;
      case "approval-list":
        return <ApprovalList />;
      case "lead-times":
        return <LeadTimes />;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar activeScreen={activeScreen} onNavigate={handleNavigate} userRole={userRole} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header userName="Admin User" userRole="Administrator" />

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto">
          <div className="p-8">
            {renderContent()}
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <p>© 2025 Smart Approval Management System. All rights reserved.</p>
            <p>Version 1.0 | Last updated: February 5, 2025</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
